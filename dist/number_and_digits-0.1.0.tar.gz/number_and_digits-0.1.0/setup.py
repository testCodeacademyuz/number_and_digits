from setuptools import setup

setup(
   name='number_and_digits',
   version='0.1.0',
   packages=['number_and_digits'],
   description='This is Number and Digits Test',
   install_requires=[
       "requests",
   ]
) 